const data= [
  {
    name: "TV(거실)",
    population: 152205,
    color: "#0040FF",
    legendFontColor: "#7F7F7F",
    legendFontSize: 10
  },
  {
    name: "TV(침실1)",
    population: 59365,
    color: "#2E2E2E",
    legendFontColor: "#7F7F7F",
    legendFontSize: 10
  },
  {
    name: "세탁기(발코니2)",
    population: 10760,
    color: "#424242",
    legendFontColor: "#7F7F7F",
    legendFontSize: 10
  },
  {
    name: "에어컨(거실)",
    population: 1064775,
    color: "#585858",
    legendFontColor: "#7F7F7F",
    legendFontSize: 10
  },
  {
    name: "전기밥솥(주방)",
    population: 125907,
    color: "#6E6E6E",
    legendFontColor: "#7F7F7F",
    legendFontSize: 10
  },
  {
    name: "커피포트(주방)",
    population: 12669,
    color: "#A4A4A4",
    legendFontColor: "#7F7F7F",
    legendFontSize: 10
  },{
    name: "컴퓨터(방3)",
    population: 17764,
    color: "#BDBDBD",
    legendFontColor: "#7F7F7F",
    legendFontSize: 10
  },
  {
    name: "컴퓨터(침실3)",
    population: 52639,
    color: "#D8D8D8",
    legendFontColor: "#7F7F7F",
    legendFontSize: 10
  }
];
module.exports = data