const month1={
    labels: ["7","8","9","10","11","12","1","2","3","4","5","6","7"],
    datasets: [
      {
        data: [4965203,2006854,904458,992093,899565,1099263,1117315,976467,1025501,958545,797869,876260,5299527],
        color: (opacity = 1) => `rgba(255, 255, 0)`, // optional
        strokeWidth: 2 // optional
      },
      {
        data: [4965203,2006854,904458,992093,899565,1099263,1117315,976467,1025501,958545,797869,876260,1496087],
        color: (opacity = 1) => `rgba(0, 0, 255)`, // optional, ${opacity}
        strokeWidth: 2 // optional
      }
    ],
  };
module.exports = month1